﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {

    [SerializeField]
    public AudioClip[] music = new AudioClip[10];//or however many songs we have

    [SerializeField]
    public AudioClip[] sfx = new AudioClip[100];

    public float musicVolume;
    public float sfxVolume;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
