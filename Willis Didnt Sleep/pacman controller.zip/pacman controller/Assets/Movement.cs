﻿using UnityEngine;
using System.Collections;

public class Movement : MonoBehaviour
{

    public GameObject pacMan;
    
    public float speed = 10.0f;
    public float jumpSpeed = 8.0f;
    public float gravity = 20.0f;

    private Vector3 direction = Vector3.zero;

    // Use this for initialization
    void Start()
    {
        pacMan = GameObject.FindGameObjectWithTag("Player");
        
    }

    // Update is called once per frame
    void Update()
    {
        CharacterController contr = pacMan.GetComponent<CharacterController>();
        if (contr.isGrounded)
        {
            direction = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            direction = transform.TransformDirection(direction);
            direction *= speed;
            if (Input.GetButton("Jump"))
                direction.y = jumpSpeed;
        }

        direction.y -= gravity * Time.deltaTime;
        contr.Move(direction * Time.deltaTime);
        //pacMan.transform.rotation = Quaternion.LookRotation(direction.normalized);
    }
}