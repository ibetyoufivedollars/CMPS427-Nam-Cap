﻿using UnityEngine;
using System.Collections;

public class cameraMovement : MonoBehaviour {

    public float turnSpeed = 0.40f;
    public Transform player;

    void Update()
    {
        transform.position = new Vector3(player.position.x, player.position.y + 8.0f, player.position.z - 7.0f);

        transform.LookAt(player.position);

        transform.RotateAround(player.transform.position, Vector3.up, Input.GetAxis("Mouse X") * turnSpeed);
    }
}
